<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ServiceDetailsrController extends Controller
{
    public function index ()
    {
        return view('service-details');
    }
}
