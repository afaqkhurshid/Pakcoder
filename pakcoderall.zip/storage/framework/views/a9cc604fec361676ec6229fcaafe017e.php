<header id="header" class="header fixed-top">
  <div class="topbar d-flex align-items-center dark-background">
    <div class="container d-flex justify-content-center justify-content-md-between">
      <div class="contact-info d-flex align-items-center">
        <i class="bi bi-envelope d-flex align-items-center"><a href="mailto:thepakcoder@gmail.com">thepakcoder@gmail.com</a></i>
        <i class="bi bi-phone d-flex align-items-center ms-4"><span>+92 313 4672846</span></i>
      </div>
      
        
      
    </div>
  </div><!-- End Top Bar -->
  <div class="branding d-flex align-items-center">
    <div class="container position-relative d-flex align-items-center justify-content-between">
      <a href="<?php echo e(url('/')); ?>" class="logo d-flex align-items-center">
        <!-- Uncomment the line below if you also wish to use an image logo -->
        
            <img src="<?php echo e(asset('/img/logopak.png')); ?>" alt="Passion Logo" style="max-height: 170px; position:absolute;">
        
        <!-- <img src="assets/img/logo.webp" alt=""> -->
        
      </h1>
      </a>
      <nav id="navmenu" class="navmenu">
        <ul>
          <li><a href="<?php echo e(url('/')); ?>" class="active">Home</a></li>
          <li><a href="<?php echo e(url('/')); ?>#about">About</a></li>
          <li><a href="<?php echo e(url('/')); ?>#services">Services</a></li>
          <li><a href="<?php echo e(url('/')); ?>#portfolio">Portfolio</a></li>
          <li><a href="<?php echo e(url('/')); ?>#team">Team</a></li>
          
          <!-- Megamenu 2 -->
          
          <!-- End Megamenu 2 -->
          <li><a href="#contact">Contact</a></li>
        </ul>
        <i class="mobile-nav-toggle d-xl-none bi bi-list"></i>
      </nav>
    </div>
  </div>
</header><?php /**PATH D:\pakcoder\resources\views\layouts\header.blade.php ENDPATH**/ ?>