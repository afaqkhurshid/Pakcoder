<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Contact Form Message</title>
</head>
<body>
    <h2>New Contact Form Submission</h2>
    <p><strong>Name:</strong> <?php echo e($data['name']); ?></p>
    <p><strong>Email:</strong> <?php echo e($data['email']); ?></p>
    <p><strong>Phone:</strong> <?php echo e($data['phone'] ?? 'N/A'); ?></p>
    <p><strong>Service:</strong> <?php echo e($data['service'] ?? 'Not specified'); ?></p>
    <p><strong>Message:</strong></p>
    <p><?php echo e($data['message']); ?></p>   
</body>
</html>
<?php /**PATH D:\pakcoder\resources\views\emails\contact_form.blade.php ENDPATH**/ ?>