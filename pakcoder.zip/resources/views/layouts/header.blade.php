<header id="header" class="header fixed-top">
  <div class="topbar d-flex align-items-center dark-background">
    <div class="container d-flex justify-content-center justify-content-md-between">
      <div class="contact-info d-flex align-items-center">
        <i class="bi bi-envelope d-flex align-items-center" style="z-index: 9999;"><a href="mailto:thepakcoder@gmail.com">thepakcoder@gmail.com</a></i>
        <i class="bi bi-phone d-flex align-items-center ms-4"><a href="tel:+923134672846"><span>+92 313 4672846</span></a></i>
      </div>
      <div class="social-links d-none d-md-flex align-items-center">
        <a href="https://wa.me/923134672846" target="_blank" title="WhatsApp"><i class="bi bi-whatsapp"></i></a>
      </div>
    </div>
  </div><!-- End Top Bar -->
  <div class="branding d-flex align-items-center">
    <div class="container position-relative d-flex align-items-center justify-content-between">
      <a href="{{ url('/') }}" class="logo d-flex align-items-center">
        <!-- Uncomment the line below if you also wish to use an image logo -->
        {{-- <a href="{{ url('/') }}"> --}}
            <img src="{{ asset('/img/logopak.png') }}" alt="Passion Logo" style="max-height: 170px; position:absolute;">
        {{-- </a> --}}
        <!-- <img src="assets/img/logo.webp" alt=""> -->
        {{-- <h1 class="sitename"> --}}
      </h1>
      </a>
      <nav id="navmenu" class="navmenu">
        <ul>
          <li><a href="{{ url('/') }}" class="active">Home</a></li>
          <li><a href="{{ url('/') }}#about">About</a></li>
          <li><a href="{{ url('/') }}#services">Services</a></li>
          <li><a href="{{ url('/') }}#portfolio">Portfolio</a></li>
          <li><a href="{{ url('/') }}#team">Team</a></li>
          {{-- <li class="dropdown"><a href="#"><span>Dropdown</span> <i class="bi bi-chevron-down toggle-dropdown"></i></a>
            <ul>
              <li><a href="#">Dropdown 1</a></li>
              <li class="dropdown"><a href="#"><span>Deep Dropdown</span> <i class="bi bi-chevron-down toggle-dropdown"></i></a>
                <ul>
                  <li><a href="https://wa.me/923134672846" target="_blank" title="WhatsApp"><i class="bi bi-whatsapp"></i></a></li>
                  <li><a href="#">Deep Dropdown 2</a></li>
                  <li><a href="#">Deep Dropdown 3</a></li>
                  <li><a href="#">Deep Dropdown 4</a></li>
                  <li><a href="#">Deep Dropdown 5</a></li>
                </ul>
              </li>
              <li><a href="#">Dropdown 2</a></li>
              <li><a href="#">Dropdown 3</a></li>
              <li><a href="#">Dropdown 4</a></li>
            </ul>
          </li> --}}
          <!-- Megamenu 2 -->
          {{-- <li class="megamenu-2"><a href="#"><span>Megamenu</span> <i class="bi bi-chevron-down toggle-dropdown"></i></a>
            <!-- Mobile Megamenu -->
            <ul class="mobile-megamenu">
              <li><a href="#">Product Analytics</a></li>
              <li><a href="#">Customer Insights</a></li>
              <li><a href="#">Market Research</a></li>
              <li class="dropdown"><a href="#"><span>Enterprise Software</span> <i class="bi bi-chevron-down toggle-dropdown"></i></a>
                <ul>
                  <li><a href="#">CRM Solutions</a></li>
                  <li><a href="#">ERP Systems</a></li>
                  <li><a href="#">Workflow Automation</a></li>
                  <li><a href="#">Document Management</a></li>
                  <li><a href="#">Business Intelligence</a></li>
                  <li><a href="#">Integration Platform</a></li>
                </ul>
              </li>
              <li class="dropdown"><a href="#"><span>Development Tools</span> <i class="bi bi-chevron-down toggle-dropdown"></i></a>
                <ul>
                  <li><a href="#">Code Editors</a></li>
                  <li><a href="#">Version Control</a></li>
                  <li><a href="#">Testing Frameworks</a></li>
                  <li><a href="#">Deployment Tools</a></li>
                  <li><a href="#">API Management</a></li>
                  <li><a href="#">Performance Monitoring</a></li>
                </ul>
              </li>
              <li class="dropdown"><a href="#"><span>Creative Suite</span> <i class="bi bi-chevron-down toggle-dropdown"></i></a>
                <ul>
                  <li><a href="#">Design Software</a></li>
                  <li><a href="#">Video Editing</a></li>
                  <li><a href="#">Audio Production</a></li>
                  <li><a href="#">Animation Tools</a></li>
                  <li><a href="#">Photo Editing</a></li>
                  <li><a href="#">3D Modeling</a></li>
                </ul>
              </li>
              <li class="dropdown"><a href="#"><span>Resources</span> <i class="bi bi-chevron-down toggle-dropdown"></i></a>
                <ul>
                  <li><a href="#">Documentation</a></li>
                  <li><a href="#">Tutorials</a></li>
                  <li><a href="#">Community</a></li>
                  <li><a href="#">Blog Posts</a></li>
                </ul>
              </li>
            </ul><!-- End Mobile Megamenu -->
            <!-- Desktop Megamenu -->
            <div class="desktop-megamenu">
              <div class="tab-navigation">
                <ul class="nav nav-tabs flex-column" id="2190-megamenu-tabs" role="tablist">
                  <li class="nav-item" role="presentation">
                    <button class="nav-link active" id="2190-tab-1-tab" data-bs-toggle="tab" data-bs-target="#2190-tab-1" type="button" role="tab" aria-controls="2190-tab-1" aria-selected="true">
                      <i class="bi bi-building-gear"></i>
                      <span>Enterprise Software</span>
                    </button>
                  </li>
                  <li class="nav-item" role="presentation">
                    <button class="nav-link" id="2190-tab-2-tab" data-bs-toggle="tab" data-bs-target="#2190-tab-2" type="button" role="tab" aria-controls="2190-tab-2" aria-selected="false">
                      <i class="bi bi-code-slash"></i>
                      <span>Development Tools</span>
                    </button>
                  </li>
                  <li class="nav-item" role="presentation">
                    <button class="nav-link" id="2190-tab-3-tab" data-bs-toggle="tab" data-bs-target="#2190-tab-3" type="button" role="tab" aria-controls="2190-tab-3" aria-selected="false">
                      <i class="bi bi-palette"></i>
                      <span>Creative Suite</span>
                    </button>
                  </li>
                  <li class="nav-item" role="presentation">
                    <button class="nav-link" id="2190-tab-4-tab" data-bs-toggle="tab" data-bs-target="#2190-tab-4" type="button" role="tab" aria-controls="2190-tab-4" aria-selected="false">
                      <i class="bi bi-journal-text"></i>
                      <span>Resources</span>
                    </button>
                  </li>
                </ul>
              </div>
              <div class="tab-content">
                <!-- Enterprise Software Tab -->
                <div class="tab-pane fade show active" id="2190-tab-1" role="tabpanel" aria-labelledby="2190-tab-1-tab">
                  <div class="content-grid">
                    <div class="product-section">
                      <h4>Core Solutions</h4>
                      <div class="product-list">
                        <a href="#" class="product-link">
                          <i class="bi bi-people"></i>
                          <div>
                            <span>CRM Solutions</span>
                            <small>Manage customer relationships effectively</small>
                          </div>
                        </a>
                        <a href="#" class="product-link">
                          <i class="bi bi-diagram-3"></i>
                          <div>
                            <span>ERP Systems</span>
                            <small>Integrate all business processes</small>
                          </div>
                        </a>
                        <a href="#" class="product-link">
                          <i class="bi bi-gear-wide"></i>
                          <div>
                            <span>Workflow Automation</span>
                            <small>Streamline repetitive tasks</small>
                          </div>
                        </a>
                      </div>
                    </div>
                    <div class="product-section">
                      <h4>Data &amp; Analytics</h4>
                      <div class="product-list">
                        <a href="#" class="product-link">
                          <i class="bi bi-file-earmark-text"></i>
                          <div>
                            <span>Document Management</span>
                            <small>Organize and secure documents</small>
                          </div>
                        </a>
                        <a href="#" class="product-link">
                          <i class="bi bi-bar-chart"></i>
                          <div>
                            <span>Business Intelligence</span>
                            <small>Make data-driven decisions</small>
                          </div>
                        </a>
                        <a href="#" class="product-link">
                          <i class="bi bi-share"></i>
                          <div>
                            <span>Integration Platform</span>
                            <small>Connect all your systems</small>
                          </div>
                        </a>
                      </div>
                    </div>
                  </div>
                  <div class="featured-banner">
                    <div class="banner-content">
                      <img src="assets/img/misc/misc-7.webp" alt="Enterprise Solutions" class="banner-image">
                      <div class="banner-info">
                        <h5>Enterprise Package</h5>
                        <p>Comprehensive business management solution with advanced features and 24/7 support.</p>
                        <a href="#" class="cta-btn">Get Started <i class="bi bi-arrow-right"></i></a>
                      </div>
                    </div>
                  </div>
                </div>
                <!-- Development Tools Tab -->
                <div class="tab-pane fade" id="2190-tab-2" role="tabpanel" aria-labelledby="2190-tab-2-tab">
                  <div class="content-grid">
                    <div class="product-section">
                      <h4>Code &amp; Build</h4>
                      <div class="product-list">
                        <a href="#" class="product-link">
                          <i class="bi bi-code-square"></i>
                          <div>
                            <span>Code Editors</span>
                            <small>Advanced development environment</small>
                          </div>
                        </a>
                        <a href="#" class="product-link">
                          <i class="bi bi-git"></i>
                          <div>
                            <span>Version Control</span>
                            <small>Track changes and collaborate</small>
                          </div>
                        </a>
                        <a href="#" class="product-link">
                          <i class="bi bi-check2-square"></i>
                          <div>
                            <span>Testing Frameworks</span>
                            <small>Ensure code quality</small>
                          </div>
                        </a>
                      </div>
                    </div>
                    <div class="product-section">
                      <h4>Deploy &amp; Monitor</h4>
                      <div class="product-list">
                        <a href="#" class="product-link">
                          <i class="bi bi-cloud-upload"></i>
                          <div>
                            <span>Deployment Tools</span>
                            <small>Seamless application deployment</small>
                          </div>
                        </a>
                        <a href="#" class="product-link">
                          <i class="bi bi-api"></i>
                          <div>
                            <span>API Management</span>
                            <small>Design and manage APIs</small>
                          </div>
                        </a>
                        <a href="#" class="product-link">
                          <i class="bi bi-speedometer2"></i>
                          <div>
                            <span>Performance Monitoring</span>
                            <small>Track application performance</small>
                          </div>
                        </a>
                      </div>
                    </div>
                  </div>
                  <div class="featured-banner">
                    <div class="banner-content">
                      <img src="assets/img/misc/misc-12.webp" alt="Development Tools" class="banner-image">
                      <div class="banner-info">
                        <h5>Developer Suite</h5>
                        <p>Complete toolkit for modern development teams with integrated CI/CD pipelines.</p>
                        <a href="#" class="cta-btn">Explore Tools <i class="bi bi-arrow-right"></i></a>
                      </div>
                    </div>
                  </div>
                </div>
                <!-- Creative Suite Tab -->
                <div class="tab-pane fade" id="2190-tab-3" role="tabpanel" aria-labelledby="2190-tab-3-tab">
                  <div class="content-grid">
                    <div class="product-section">
                      <h4>Design &amp; Visual</h4>
                      <div class="product-list">
                        <a href="#" class="product-link">
                          <i class="bi bi-brush"></i>
                          <div>
                            <span>Design Software</span>
                            <small>Professional graphic design tools</small>
                          </div>
                        </a>
                        <a href="#" class="product-link">
                          <i class="bi bi-camera-video"></i>
                          <div>
                            <span>Video Editing</span>
                            <small>Professional video production</small>
                          </div>
                        </a>
                        <a href="#" class="product-link">
                          <i class="bi bi-image"></i>
                          <div>
                            <span>Photo Editing</span>
                            <small>Advanced image manipulation</small>
                          </div>
                        </a>
                      </div>
                    </div>
                    <div class="product-section">
                      <h4>Media Production</h4>
                      <div class="product-list">
                        <a href="#" class="product-link">
                          <i class="bi bi-music-note"></i>
                          <div>
                            <span>Audio Production</span>
                            <small>Professional audio editing</small>
                          </div>
                        </a>
                        <a href="#" class="product-link">
                          <i class="bi bi-play-circle"></i>
                          <div>
                            <span>Animation Tools</span>
                            <small>Create stunning animations</small>
                          </div>
                        </a>
                        <a href="#" class="product-link">
                          <i class="bi bi-box"></i>
                          <div>
                            <span>3D Modeling</span>
                            <small>Advanced 3D design software</small>
                          </div>
                        </a>
                      </div>
                    </div>
                  </div>
                  <div class="featured-banner">
                    <div class="banner-content">
                      <img src="assets/img/misc/misc-5.webp" alt="Creative Suite" class="banner-image">
                      <div class="banner-info">
                        <h5>Creative Pro</h5>
                        <p>Everything you need for creative projects, from concept to final production.</p>
                        <a href="#" class="cta-btn">Start Creating <i class="bi bi-arrow-right"></i></a>
                      </div>
                    </div>
                  </div>
                </div>
                <!-- Resources Tab -->
                <div class="tab-pane fade" id="2190-tab-4" role="tabpanel" aria-labelledby="2190-tab-4-tab">
                  <div class="resources-layout">
                    <div class="resource-categories">
                      <div class="resource-category">
                        <i class="bi bi-book"></i>
                        <h5>Documentation</h5>
                        <p>Comprehensive guides and API references for all our products and services.</p>
                        <a href="#" class="resource-link">Browse Docs <i class="bi bi-arrow-right"></i></a>
                      </div>
                      <div class="resource-category">
                        <i class="bi bi-play-circle"></i>
                        <h5>Video Tutorials</h5>
                        <p>Step-by-step video guides to help you get the most out of our solutions.</p>
                        <a href="#" class="resource-link">Watch Tutorials <i class="bi bi-arrow-right"></i></a>
                      </div>
                      <div class="resource-category">
                        <i class="bi bi-chat-square-dots"></i>
                        <h5>Community Forum</h5>
                        <p>Connect with other users, share tips, and get answers to your questions.</p>
                        <a href="#" class="resource-link">Join Community <i class="bi bi-arrow-right"></i></a>
                      </div>
                      <div class="resource-category">
                        <i class="bi bi-newspaper"></i>
                        <h5>Blog &amp; Articles</h5>
                        <p>Latest insights, best practices, and industry trends from our experts.</p>
                        <a href="#" class="resource-link">Read Blog <i class="bi bi-arrow-right"></i></a>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div><!-- End Desktop Megamenu -->
          </li> --}}
          <!-- End Megamenu 2 -->
          <li><a href="{{ route('contact') }}">Contact</a></li>
          {{-- <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="languageDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              {{ app()->getLocale() == 'ar' ? 'العربية (Arabic)' : 'English' }}
            </a>
            <ul class="dropdown-menu" aria-labelledby="languageDropdown">
                <li><a class="dropdown-item" href="{{ url('/en') }}">English</a></li>
                <li><a class="dropdown-item" href="{{ url('/ar') }}">العربية (Arabic)</a></li>
            </ul>
          </li> --}}
        </ul>
        <i class="mobile-nav-toggle d-xl-none bi bi-list"></i>
      </nav>
    </div>
  </div>
</header>